# FastAPI 从入门到实战

# 课程视频：​[FastAPI 从入门到实战课程视频](https://q0kyes8lnt5.feishu.cn/wiki/CRuewLGd7iAC5OkgnRpcAgj9nKe?from=from_copylink)​

# 课程代码：​[FastAPI 从入门到实战课程代码](https://q0kyes8lnt5.feishu.cn/wiki/McrEwbKm8iDEMWkJiVXcvOe0nNb?from=from_copylink)​

# 作业代码：​[FastAPI 作业参考代码](https://q0kyes8lnt5.feishu.cn/wiki/VDazwxc0NiW4lZk9sxHcXZxQnlc)​

# 引言：为什么大模型应用开发，绕不开 FastAPI？​

在学习大模型应用开发时，很多人都会产生一个疑问：**为什么课程没有直接从模型开始，而是先学习 FastAPI？**​

原因在于，大模型只是应用中的一部分，而不是完整的应用本身。真正能够对外提供服务的大模型系统，除了模型之外，还需要具备接口、业务逻辑、数据处理等基础能力。因此，在学习模型之前，需要先建立**应用开发**的基本框架。​

从应用架构来看，大模型应用通常包含两部分：​

- •一部分负责对外提供服务，接收用户请求并返回结果；​
- •另一部分负责具体的业务处理，后续会逐步接入 Prompt、RAG、Agent 等大模型能力。​

因此，本章学习 FastAPI 的目的并不是立即调用大模型，而是掌握如何将 Python 程序构建成一个可运行、可调用、可扩展的服务，为后续接入大模型做好准备。​

## 一、FastAPI 是什么？​

在这门课里，你可以先这样理解 **FastAPI**：​

> ​**FastAPI 是一个用 Python 写接口服务的工具，它可以把你的 Python 函数，变成别人可以通过网络调用的接口。**​​

**FastAPI 是一个用 Python 写接口服务的工具，它可以把你的 Python 函数，变成别人可以通过网络调用的接口。**​

- •使用 FastAPI 后，开发者编写的仍然是 Python 函数，只是在框架的支持下，这些函数不仅能够在本地运行，还可以通过网络对外提供服务，供其他程序进行调用。​
- •对于调用者而言，并不需要了解程序的内部实现，只需要按照接口规定传入数据，即可获得对应的处理结果。​

这正是后面所有“大模型应用”的基本形态。​

## 二、从脚本到应用：你缺的不是语法，是「交付方式」​

完成 Python 基础学习后，通常已经能够编写函数、类以及各种脚本程序，并在本地完成相应功能。​

但这类代码有一个天然限制： ​

> ​**它只适合你自己运行，不适合直接给别人用，也不适合接入系统。**​​

**它只适合你自己运行，不适合直接给别人用，也不适合接入系统。**​

在真实场景中，一个**能被使用的程序**通常需要：​

- •有固定入口（别人知道从哪里调用）​
- •输入输出有规范（不容易传错参数）​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

本文暂未被其它文档引用

- •能稳定运行（出错可控、可以重复调用）​

FastAPI 解决的，正是这一层问题：​

> ​**把你的 Python 能力，包装成 “可调用、可集成、可测试”的接口服务。**​​

**把你的 Python 能力，包装成 “可调用、可集成、可测试”的接口服务。**​

## 三、为什么要在学模型之前学 FastAPI？​

因为在后续学习中，你写的程序会从“简单逻辑”，逐步升级为**更复杂、更智能的处理过程**。​

如果这些逻辑只是零散地写在不同的 Python 文件中，你学到的内容就很难组合成一个完整的应用。​

而 FastAPI 提供的，正是一个**统一的应用外壳**：​

- •我们可以先搭好一个服务结构​
- •先让接口跑起来（哪怕内部只是返回固定内容）​
- •后面再不断替换、升级内部逻辑​

你会清楚看到：​

> ​**应用不是一次写完的，而是一层一层长出来的。**​​

**应用不是一次写完的，而是一层一层长出来的。**​

## 四、为什么选 FastAPI，而不是 Flask / Django？​

在 Python 生态中，常见的 Web 框架主要有 Flask、Django 和 FastAPI。​ 在当前这个学习阶段，我们更关注的是**接口服务本身**。​

### Flask：很轻，很自由，但容易“越写越乱”​

- •特点是“想怎么写都行”​
- •灵活，但很多规则需要自己补​
- •对初学者来说，容易出现：能跑，但不稳定；能用，但不好维护​

### Django：功能很全，但对“模型接口服务”来说太重​

- •像一个大型工具箱，什么都准备好了​
- •更适合完整网站或管理系统​
- •但在“先学接口、再接模型”的阶段，学习负担偏重​

### FastAPI：轻 + 规则清楚 + 调试方便​

- •代码量不多，写法接近 Python 函数​
- •对输入输出的结构要求清晰​
- •自带接口测试页面，调试直观​
- •非常适合作为“模型应用服务的起点”​

因此我们选择 FastAPI 的原因很直接：​

> ​**用最少的代码，把 Python 程序变成 稳定、清晰、好调用的接口服务。**​​

**用最少的代码，把 Python 程序变成 稳定、清晰、好调用的接口服务。**​

## 五、这一阶段你需要达到的学习成果​

学完 FastAPI 后，你不需要成为后端工程师，但你应该能够：​

- •用 Python 写一个对外接口​
- •清楚定义输入参数和返回结果​
- •在浏览器中测试你的接口​
- •把“一个脚本”组织成“一个服务项目”的基本结构​

在此基础上，后续学习的大模型能力将不断接入同一个应用中，最终形成一个完整的大模型应用系统。​

# 第一阶段：基础铺垫与 Hello World​

## 第1章：现代 Python 语法与 HTTP 基础​

### 1.Python 类型提示 (Type Hints)​

Python 是一种**动态类型语言**，变量类型在运行过程中由解释器自动推断，不需要像 Java、C++ 等静态类型语言一样提前声明变量类型。​

例如：​

```
代码块​Pythonname = "Tom"​age = 18​
```

Python 解释器会根据当前赋值对象确定变量引用的对象类型​

但是，随着项目规模不断扩大，仅依靠动态类型会带来一些问题，例如：​

```
代码块​Pythondef process(data)​
```

- •代码可读性降低，其他开发者难以快速理解变量类型。​
- •编辑器无法提供准确的代码提示。​
- •运行过程中才可能发现类型错误。​

因此，Python 在 3.5 版本引入了 **Type Hints（类型提示）**，提供类型提示信息。​

```
讲课例子​Pythondef process(data: dict) -> str​def add(a: int, b: int) -> int​
```

需要注意的是，Type Hints 不会改变 Python 本身动态类型的特性，它主要用于：​

```
讲课例子​Pythondef get_user(user_id: int) -> User​
```

1. 1.提高代码可读性：明确变量和函数参数的数据类型。​
2. 2.增强编辑器支持：IDE 可以根据类型信息提供代码补全和错误提示。​
3. 3.支持框架自动处理：例如 FastAPI 会利用类型提示完成参数校验、数据转换以及 API 文档生成。​

FastAPI 能够实现自动接口文档和请求参数校验，其中一个重要基础就是 Python 的类型提示。​

**语法格式**：​

```
代码块​Python
```

**代码示例**：​

```
代码块​Python# 传统写法​def get_full_name(first_name, last_name):​    return first_name.title() + " " + last_name.title()​​# 现代写法 (Type Hints)​def get_full_name_typed(first_name: str, last_name: str) -> str:​    #编辑器知道 first_name 是 str，会自动提示 .title() 方法​    return first_name.title() + " " + last_name.title()​
```

**类型提示的优势**：​

| ​优势​​ | ​说明​​ |
| --- | --- |

​优势​​

优势​

​说明​​

说明​

​代码可读性提升​​

代码可读性提升​

​通过类型声明可以快速了解变量和函数的数据结构​​

通过类型声明可以快速了解变量和函数的数据结构​

​编辑器支持​​

编辑器支持​

​IDE（VS Code、PyCharm 等）可以提供更准确的代码补全和检查​​

IDE（VS Code、PyCharm 等）可以提供更准确的代码补全和检查​

​FastAPI 的基础能力​​

FastAPI 的基础能力​

​FastAPI 根据类型信息实现请求参数解析、校验以及自动生成接口文档​​

FastAPI 根据类型信息实现请求参数解析、校验以及自动生成接口文档​

#### 1.1复杂类型 (List, Dict, Optional, Union) ​

在实际开发中，数据通常不会只有简单的字符串、数字类型，还会涉及列表、字典以及可能为空的数据。​

Python 提供了 `typing` 模块来描述这些复杂类型。​

常见类型包括：​

- •**List (列表)：**`List[int]` 表示一个只包含整数的列表。​
- •**Dict (字典)：**`Dict[str, int]` 表示键为字符串、值为整数的字典。{"scores":95,"age":18}​
- •**Optional (可选类型)：**`Optional[str]` 表示该值可以是字符串，也可以是 `None`。​
- •**Union (联合类型)：**`Union[int, str]` 表示该值可以是整数或字符串。​

> 🌟 这里需要注意 Python 是区分大小写的：​
> 🌟 List[int]：这是 typing 模块提供的旧式写法​
> 🌟 list[int]：这是 Python 3.9 之后推荐的内置泛型写法​

这里需要注意 Python 是区分大小写的：​

- •List[int]：这是 typing 模块提供的旧式写法​
- •list[int]：这是 Python 3.9 之后推荐的内置泛型写法​
- •Dict[str, int] 和 dict[str, int] 同理​

Python 3.9 之后，可以直接使用内置泛型语法，不再需要导入 `List`、`Dict`。​

```
代码块​Pythona: list[int] = [1, 2, 3]​​b: dict[str, int] = {​    "age": 18​}​​c: str | None = None   # 等价于 Optional[str]​​d: int | str = 123     # 等价于 Union[int, str]​
```

其中：​

- •`list[int]` 表示列表中的每一个元素都应该是整数。​
- •`dict[str, int]` 表示字典的 key 必须是字符串，value 必须是整数。​
- •`str | None` 是 Python 3.10 提供的新写法，用于表示联合类型。​

实际开发中，经常会结合函数使用：​

```
代码块​Pythonfrom typing import Optional, List, Dict, Union​​# 处理成绩数据 ​def process_scores(scores: list[int]) -> dict[str, float]:​    return {​        "average": sum(scores) / len(scores)​    }​​​# 查询数据，可以传入字符串，也可以不传​def search_item(query: str | None = None) -> str | list[str]:​    if query:​        return f"Searching for {query}"​​    return ["item1", "item2"]​
```

在 FastAPI 中，这些复杂类型可以直接用于接口参数定义，例如：​

```
代码块​Python@app.post("/students")​def create_students(names: list[str]):​    return names​
```

FastAPI 会根据类型提示自动判断请求数据格式，并进行校验。​

#### 1.2Pydantic 基础简介​

FastAPI 使用 **Pydantic** 作为数据验证和数据模型定义工具。​

在 Web 开发中，客户端发送的数据通常来自用户输入，数据类型和格式可能不符合要求。例如：​

- •年龄字段应该是整数，但是用户传入字符串。​
- •邮箱字段格式错误。​
- •必填字段缺失。​

Pydantic 可以根据定义好的模型自动完成：​

- •数据格式校验。​
- •类型转换。​
- •错误信息生成。​
- •数据结构管理。​

核心方式是继承 `BaseModel` 创建数据模型。​

代码示例：​

```
代码块​Pythonfrom pydantic import BaseModel​from typing import Optional​​class Item(BaseModel):​    name: str​    price: float​    is_offer: bool = False # 可选字段，默认为 False​    ​def test(​    name: str = "World",​    price: float = 0.0,​    is_offer: bool = False​
```

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

例如：​

```
代码块​Pythonitem = Item(​    name="Phone",​    price="1999.9"​)​
```

Pydantic 会自动尝试将符合规则的数据转换为目标类型：​

```
代码块​Pythonprice = 1999.9​
```

但是：​

```
代码块​Pythonitem = Item(​    name="Phone",​    price="abc"​)​
```

由于字符串无法转换为数字，Pydantic 会返回校验错误。​

**Pydantic 的工作流程**​

### 2.Python 异步编程基础 (Async/Await)​

FastAPI 具有较高性能的重要原因之一，就是它支持异步编程模型。​

在 Web 应用中，大量操作并不是消耗 CPU，而是在等待外部资源，例如：​

- •查询数据库。​
- •调用第三方 API。​
- •读取文件。​
- •等待网络响应。​

如果采用传统同步方式，程序在等待过程中会一直占用线程资源。而异步编程可以让程序在等待期间处理其他任务，提高资源利用率。​

#### 2.1同步 vs 异步​

- •**同步 (Sync)**：排队点餐。服务员（CPU）在顾客 A 点餐思考时一直等待，不能服务顾客 B。​
- •**异步 (Async)**：叫号取餐。顾客 A 点餐思考时，服务员去服务顾客 B，等 A 好了再回来。​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

例如：​

#### 2.2async 与 await 关键字​

Python 通过 `async` 和 `await` 实现异步编程。​

- •async def：定义一个异步函数，也称为协程函数。​
- •await：等待一个异步任务完成，同时将控制权交给事件循环，让其他任务继续执行。​

例如：​

```
代码块​Pythonasync def get_data():​    result = await request_data()​    return result​
```

当执行到 `await` 时，如果数据还没有返回，当前任务会暂停，事件循环可以执行其他协程。​

#### 2.3阻塞等待和非阻塞等待​

| ​**类别**​​ | ​**具体说明**​​ |
| --- | --- |

​**类别**​​

**类别**​

​**具体说明**​​

**具体说明**​

​阻塞等待（基本概念）​​

阻塞等待（基本概念）​

​程序执行被暂停，当前线程完全停止工作直到等待时间结束​​

程序执行被暂停，当前线程完全停止工作直到等待时间结束​

​非阻塞等待（基本概念）​​

非阻塞等待（基本概念）​

​程序释放控制权给事件循环，允许其他任务并发执行​​

程序释放控制权给事件循环，允许其他任务并发执行​

​阻塞等待 (time.sleep ())​​

阻塞等待 (time.sleep ())​

​使用 time.sleep () 实现完全冻结当前线程的所有操作事件循环被阻止执行其他任务在异步环境中破坏并发性能​​

使用 time.sleep () 实现完全冻结当前线程的所有操作事件循环被阻止执行其他任务在异步环境中破坏并发性能​

​​

​​

非阻塞等待 (asyncio.sleep ())​

使用 await asyncio.sleep () 实现将控制权交还给事件循环允许其他协程在此期间运行保持异步程序的并发特性​

例如：​

```
代码块​Pythonimport asyncio​import time​​​async def make_coffee():​    print("开始煮咖啡...")​    #time.sleep(3)​    await asyncio.sleep(3)  # 煮咖啡需要 3 秒​    print("咖啡好了！")​​async def make_toast():​    print("开始烤面包...")​    await asyncio.sleep(2)  # 烤面包需要 2 秒​    print("面包好了！")​​async def main():​
```

两个任务并不是同时执行，而是在遇到 I/O 等待时主动切换，让事件循环调度其他任务。​

> ​注意：在 `async def` 函数中，如果调用耗时的同步函数，例如 `time.sleep()`，会阻塞整个事件循环。异步代码中应该优先使用支持异步的函数，例如 `asyncio.sleep()`。​​

注意：在 `async def` 函数中，如果调用耗时的同步函数，例如 `time.sleep()`，会阻塞整个事件循环。异步代码中应该优先使用支持异步的函数，例如 `asyncio.sleep()`。​

### 3.HTTP 协议​

HTTP（HyperText Transfer Protocol，超文本传输协议）是一种用于客户端和服务器之间通信的应用层协议。​

在 Web 应用中，浏览器、移动端应用或者其他服务通常作为客户端，通过 HTTP 向服务器发送请求，服务器处理后返回响应。​

**简单理解**：​

[http://127.0.0.1:8000/users/1](http://127.0.0.1:8000/users/1)​

- •你在浏览器输入网址，按回车 → 浏览器发送 **HTTP 请求 **​
- •服务器收到请求，处理后返回数据 → 服务器发送 **HTTP 响应**​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

一个 HTTP 请求由四部分组成：​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

1. 1.**Method (方法)**：​​​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

#### 3.1请求 (Request) 结构​

**记忆口诀**：**增删改查 → POST DELETE PUT GET**​

- ◦`GET`: 获取资源（如：浏览网页）。​
- ◦`POST`: 提交数据（如：表单提交）。​
- ◦`PUT`: 更新资源。​
- ◦`DELETE`: 删除资源。​

```
代码块​PythonGET /products/100​POST /products​PUT /products/100​DELETE /products/100​
```

1. 2.**URL**: 资源地址 (如 `/users/1`)。​
2. 3.**Headers**: 请求头 (如 `Content-Type: application/json` / `Authorization: Bearer xxx`)​
3. 4.**Body**: ​用于携带提交的数据，通常存在于 POST、PUT、PATCH 请求中。​例如：​POST /users/register​

用于携带提交的数据，通常存在于 POST、PUT、PATCH 请求中。​

例如：​

POST /users/register​

```
代码块​Python{​    "name": "张三",​    "age": 20​}​
```

#### 3.2HTTP 响应 (Response) 结构​

服务器返回的响应也有固定结构：​

```
代码块​PythonHTTP/1.1 200 OK                    ← 状态行（状态码 + 状态描述）​Content-Type: application/json     ← 响应头​                                   ← 空行​{"id": 1, "name": "张三"}          ← 响应体（通常是 JSON）​
```

1. 1.**Status Code (状态码)**：​

| ​**状态码**​​ | ​**含义**​​ | ​**使用场景**​​ |
| --- | --- | --- |

​**状态码**​​

**状态码**​

​**含义**​​

**含义**​

​**使用场景**​​

**使用场景**​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

200 OK​

请求成功​

查询、修改成功​

201 Created​

创建成功​

新资源创建成功​

400 Bad Request​

请求参数错误​

参数格式不正确​

401 Unauthorized​

未认证​

缺少身份凭证​

403 Forbidden​

无权限访问​

用户权限不足​

404 Not Found​

资源不存在​

请求路径错误​

500 Internal Server Error​

服务端错误​

后端代码异常​

1. 2.**Headers（响应头）**​

用于描述响应信息，例如：​

```
代码块​PythonContent-Type: application/json​
```

表示返回的数据格式为 JSON。​

1. 3.**Body（响应体）**​

服务器返回的数据内容，现代 Web API 中通常使用 JSON 格式。​

JSON（JavaScript Object Notation）是一种轻量级数据交换格式，结构类似 Python 字典。​

例如：​

```
代码块​Python{​    "id": 1,​    "name": "张三",​    "email": "zhangsan@example.com",​    "is_active": true,​    "tags": [​        "学生",​        "VIP"​    ],​    "profile": {​        "age": 20,​        "city": "北京"​    }​}​
```

在 FastAPI 中，接口返回的数据通常会自动转换为 JSON 格式，这也是现代前后端分离开发中最常见的数据交换方式。​

> 🌟 课堂例子展示（此时如果没有搭建 FastAPI 环境可能无法运行 这里这是辅助课堂讲解作用）：​

课堂例子展示（此时如果没有搭建 FastAPI 环境可能无法运行 这里这是辅助课堂讲解作用）：​

```
代码块​Pythonfrom fastapi import FastAPI, HTTPException​from fastapi.responses import JSONResponse​​app = FastAPI()​​​# 200：正常返回​@app.get("/users/1")​def get_user():​    return {​        "id": 1,​        "name": "张三",​        "email": "zhangsan@example.com",​
```

```
terminal 运行​Pythonuvicorn main:app --reload​
```

访问：[http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)​

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/c3f9453b-b6b1-4411-ab3f-9101461d3886)

依次访问，查看不同状态码：​

```
代码块​BashGET  /users/1​POST /users​GET  /users/400​GET  /users/401​GET  /users/403​GET  /users/404​GET  /users/500​
```

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/d890018a-0f24-4676-8fd4-f6987408eeb7)

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/001decbd-4a01-49ec-a1a0-ddd1bcb8c5f9)

​

## 第2章：初识 FastAPI​

### 1.什么是 FastAPI？​

FastAPI 是一个用于构建 Web API 的现代 Python 框架，基于 Python 类型提示（Type Hints）设计，能够快速开发高性能、可靠的后端接口服务。​

FastAPI 主要依赖两个核心组件：​

- •**Starlette：**负责 Web 层功能，包括路由、中间件、请求处理、异步支持等。​
- •**Pydantic：**负责数据校验和数据序列化，通过 Python 类型声明自动完成数据验证。​

FastAPI 支持 Python 3.8+（不同版本要求可能有所变化，建议使用较新的 Python 版本），并且天然兼容异步编程模型。​

**核心优势：**​

1. 1.高性能​FastAPI 基于 ASGI（Asynchronous Server Gateway Interface）标准构建，能够充分利用 Python 异步能力，在高并发场景下拥有较好的性能表现。​其性能接近 Node.js 和 Go 等高性能 Web 框架，适用于接口服务、微服务以及 AI 应用后端开发。​

FastAPI 基于 ASGI（Asynchronous Server Gateway Interface）标准构建，能够充分利用 Python 异步能力，在高并发场景下拥有较好的性能表现。​

其性能接近 Node.js 和 Go 等高性能 Web 框架，适用于接口服务、微服务以及 AI 应用后端开发。​

1. 2.开发效率高​FastAPI 通过 Python 类型提示自动完成：​◦请求参数校验。​◦数据转换。​◦接口文档生成。​◦错误信息提示。​开发者只需要关注业务逻辑，可以减少大量重复代码。​

FastAPI 通过 Python 类型提示自动完成：​

- ◦请求参数校验。​
- ◦数据转换。​
- ◦接口文档生成。​
- ◦错误信息提示。​

开发者只需要关注业务逻辑，可以减少大量重复代码。​

1. 3.标准支持完善​

FastAPI 自动生成符合 OpenAPI 标准的接口文档，并支持 JSON Schema 数据结构描述。​

开发完成后，无需额外编写接口文档，前端开发人员即可通过 Swagger UI 调试接口。​

### 2.环境搭建​

#### 2.1安装依赖​

在终端（Terminal）或 CMD 中执行以下命令。建议在项目中创建虚拟环境(.venv)，避免不同项目之间的依赖冲突。​

```
代码块​Bash# 创建虚拟环境​python -m venv .venv​​# 激活环境​# powershell：​.venv\Scripts\Activate.ps1​​# cmd:​.venv\Scripts\activate.bat​​# macOS/Linux​source .venv/bin/activate​​
```

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

#### 2.2架构解析​

FastAPI 本身并不是一个完整的 Web 服务器，而是一个 Web 应用框架。​

在实际运行过程中，FastAPI 通常需要搭配 ASGI 服务器，例如 Uvicorn，由服务器负责接收客户端请求，并将请求交给 FastAPI 处理。​

整体流程如下：​

其中：​

- •客户端：可以是浏览器、前端应用、移动端 App 或其他服务。​
- •Uvicorn：负责网络通信，将 HTTP 请求转换为 Python 可以处理的数据。​
- •FastAPI：根据请求路径和请求方法匹配对应函数，并返回处理结果。​

在生产环境中，也可以使用 Gunicorn 搭配 Uvicorn Worker 部署 FastAPI 应用，以提高服务稳定性。​

### 3.最简应用：Hello World​

创建一个名为 `main.py` 的文件，输入以下代码：​

```
代码块​Pythonfrom fastapi import FastAPI​​# 1. 实例化 FastAPI 对象​app = FastAPI()​​​# 2. 定义 GET 请求接口​# 当客户端访问 GET / 时，会执行下面的函数​@app.get("/")​async def read_root() -> dict:​    # FastAPI 会自动将 Python 字典转换为 JSON 响应​    return {"message": "Hello World"}​​​# 3. 直接运行 Python 文件时启动服务​# if __name__ == "__main__":​#    import uvicorn​#​#    uvicorn.run(​#        app,​
```

#### 3.1代码解析​

- •`**app = FastAPI()**`：​创建 FastAPI 应用对象。​后续所有接口都需要通过这个对象进行注册，例如：​​代码块​Python@app.get("/")​​表示向 FastAPI 注册一个 GET 请求接口。​

创建 FastAPI 应用对象。​

后续所有接口都需要通过这个对象进行注册，例如：​

```
代码块​Python@app.get("/")​
```

表示向 FastAPI 注册一个 GET 请求接口。​

- •`**@app.get("/")**`：​路径操作装饰器，用于定义接口信息。​包含三个部分：​◦`@app`：FastAPI 应用对象。​

路径操作装饰器，用于定义接口信息。​

包含三个部分：​

- ◦`@app`：FastAPI 应用对象。​
- ◦`.get`：HTTP 请求方法。​
- ◦`"/"`：接口访问路径。​

当用户访问：​

```
代码块​PythonGET http://127.0.0.1:8000/​
```

FastAPI 会调用下面对应的函数。​

- •`**async def**`**：**​用于定义异步函数。​FastAPI 支持同步函数和异步函数：​​代码块​Pythondef function():​    pass​​或：​​代码块​Python​如果接口内部需要执行异步操作，例如数据库查询、网络请求等，推荐使用 `async def`。​如果函数内部没有异步操作，普通 `def` 同样可以正常运行。​

用于定义异步函数。​

FastAPI 支持同步函数和异步函数：​

```
代码块​Pythondef function():​    pass​
```

或：​

```
代码块​Python
```

如果接口内部需要执行异步操作，例如数据库查询、网络请求等，推荐使用 `async def`。​

如果函数内部没有异步操作，普通 `def` 同样可以正常运行。​

- •`**return dict**`：​FastAPI 会自动进行数据序列化：​接口函数中返回的是 Python 的 dict：​​代码块​Python{​    "message": "Hello World"​}​​FastAPI 会自动把这个 Python dict 序列化转换为 JSON：​

FastAPI 会自动进行数据序列化：​

接口函数中返回的是 Python 的 dict：​

```
代码块​Python{​    "message": "Hello World"​}​
```

FastAPI 会自动把这个 Python dict 序列化转换为 JSON：​

> ​虽然代码与上面的看起来一样，是因为 JSON 的对象语法跟 Python 字典的语法非常接近​​

虽然代码与上面的看起来一样，是因为 JSON 的对象语法跟 Python 字典的语法非常接近​

```
代码块​JSON{​    "message": "Hello World"​}​
```

同时自动设置响应头：​

```
代码块​PythonContent-Type: application/json​
```

### 4.运行与调试​

#### 4.1启动服务​

在终端中，确保处于 `main.py` 所在目录，运行：​

```
代码块​Bash
```

- •`main`: Python 文件名 (`main.py`)。​
- •`app`: FastAPI 实例名 (`app = FastAPI()`)。​
- •`--port`: 指定端口启动（默认端口是8000），这里端口只要不要与你本机电脑其它冲突都是ok的，比如说8001，8002都是可以。​
- •`--reload`: 代码修改后自动重启服务器（仅用于开发环境）。​

**启动成功标志**：​终端显示：`Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)`​

#### 4.2访问 API​

打开浏览器访问 `http://127.0.0.1:8000/`，可以看到返回结果：​

```
代码块​Python{​    "message": "Hello World"​
```

### 5.自动交互式文档​

FastAPI 根据代码中的类型提示和路由定义，自动生成符合 OpenAPI 标准的文档。这是 FastAPI 最受欢迎的功能之一。​

#### 5.1Swagger UI​

- •**访问地址**：`http://127.0.0.1:8000/docs`​
- •**功能**：​◦查看所有接口列表。​◦查看请求参数和返回数据格式。​◦在线调用接口。​◦测试 API 返回结果。​
- ◦查看所有接口列表。​
- ◦查看请求参数和返回数据格式。​
- ◦在线调用接口。​
- ◦测试 API 返回结果。​

其中：​

Try it out​

功能可以直接在网页中发送 HTTP 请求，无需额外使用 Postman 等接口测试工具。​

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/12050de7-103f-4d17-8b95-fdf185f2395e)

#### 5.2ReDoc​

- •**访问地址**：`http://127.0.0.1:8000/redoc`​
- •**功能**：提供另一种风格的、阅读体验更好的接口文档，适合对外发布。​

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/ae1057c6-303f-45c3-9376-ec73b9a2a6ce)

### 6.实践任务​

**任务描述**：​

1. 1.修改 `main.py`，新增一个路由 `/info`。​
2. 2.该接口使用 `GET` 方法。​
3. 3.返回包含你自己信息的 JSON 对象，结构如下：​

```
代码块​JSON{​
```

启动服务，截图 Swagger UI (`/docs`) 中调用该接口并成功返回结果的界面。​

代码如下：​

```
代码块​Pythonfrom fastapi import FastAPI​​# 1. 实例化 FastAPI 对象​app = FastAPI()​​# 2. 路径操作装饰器​# 含义：当客户端以 GET 方法访问根路径 "/" 时，运行下方的函数​@app.get("/")​async def read_root() -> dict:​    # 3. 路径操作函数​    # 直接返回字典，FastAPI 会自动转换为 JSON​    return {"message": "Hello World"}​
```

# 第二阶段：请求与响应——核心交互​

## 第 3 章：参数接收与验证​

### 1.参数接收概览​

在 FastAPI 中，客户端发送的数据主要通过以下几种方式传递给后端接口：​

- •路径参数（Path Parameters）：用于表示资源路径的一部分，例如根据用户 ID 查询用户信息。例如：/users/{user_id}​
- •查询参数（Query Parameters）：用于传递过滤条件、分页参数等额外信息，例如搜索关键词、页码。例如：/users?keyword=zhangsan&page=1&size=10​
- •请求体（Request Body）：用于提交结构化数据，例如创建用户、提交订单、上传表单数据等。例如：{"username":"zhangsan", "password":"123456"}​

FastAPI 会根据函数参数的位置、名称以及类型提示，自动判断参数来源，并结合 Pydantic 完成数据转换和验证。​

1. 1.从 HTTP 请求中提取数据。​
2. 2.将字符串形式的数据转换为对应的 Python 类型。​
3. 3.对数据进行合法性校验。​
4. 4.将验证后的数据传递给接口函数。​

例如，客户端传递的 URL 参数本质上都是字符串：​

```
代码块​Python/items/123​
```

但如果接口中声明：​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

```
代码块​Pythonasync def read_item(item_id: int):​
```

FastAPI 会自动将 `"123"` 转换为整数 `123`，并在类型不匹配时返回错误信息。​

#### 核心交互流程图​

### 2.路径参数 (Path Parameters)​

路径参数是 URL 地址的一部分，通常用于定位某一个具体资源。​

例如：​

```
代码块​PythonGET /users/1001​
```

其中 `1001` 就是用户 ID，后端可以根据这个 ID 查询对应用户。​

- •语法：在路由路径中使用 `{variable_name}` 声明参数，并在函数参数中定义同名变量。​
- •类型转换：FastAPI 会根据函数参数中的类型提示自动完成类型转换。​
- •数据校验：如果客户端传入的数据无法转换为指定类型，FastAPI 会自动返回参数验证错误。​

```
代码块​Pythonfrom fastapi import FastAPI​​app = FastAPI()​​​
```

访问：​

```
代码块​Pythonhttp://127.0.0.1:8000/items/10​
```

返回：​

```
代码块​Python{​    "item_id": 10,​
```

可以看到，虽然 URL 中传递的是字符串 `"10"`，但是 FastAPI 根据类型提示自动转换成了 Python 中的整数类型。​

### 3.查询参数 (Query Parameters)​

查询参数是 URL 中 `?` 后面的参数，通常用于实现筛选、搜索、分页等功能。​

例如：​

```
代码块​PythonGET /users/?skip=20&limit=5&q=admin​
```

其中：​

- •`skip=20` 表示跳过前 20 条数据。​
- •`limit=5` 表示每次返回 5 条数据。​
- •`q=admin` 表示搜索关键词。​

在 FastAPI 中，只要函数参数没有出现在路径 `{}` 中，就会自动被识别为查询参数。​

- •**默认值：**通过给参数设置默认值，可以指定参数的默认行为。​
- •**可选参数：**使用 `Optional` 或 `Union` 表示参数可以为空。​
- •**类型转换：**FastAPI 会自动将参数转换为对应的数据类型。​

```
代码块​Pythonfrom typing import Union​from fastapi import FastAPI​​app = FastAPI()​​​@app.get("/users/")​async def read_users(​    skip: int = 0,​    limit: int = 10,​    q: str | None = None ​    # q: Optional[str] = None​):​    # URL 示例：​    # /users/?skip=20&limit=5&q=admin​​
```

例如请求：​

```
代码块​Python
```

FastAPI 会自动转换为：​

```
代码块​Pythonskip = 20​limit = 5​q = "admin"​
```

对于布尔类型参数，FastAPI 也支持常见字符串转换：​

```
代码块​Python?is_active=true​?is_active=1​?is_active=yes​?is_active=on​
```

都会被转换为 True​

### 4.核心重点：请求体与 Pydantic 模型​

在实际开发中，创建或修改资源时通常需要提交一组结构化数据，例如：​

- •创建用户，需要提交用户名、密码、邮箱。​
- •创建商品，需要提交名称、价格、库存。​
- •创建订单，需要提交多个字段。​

这种情况下，单纯使用路径参数或查询参数并不适合，而应该使用 请求体（Request Body）。​

FastAPI 通常结合 Pydantic 模型 定义请求数据结构。当接口参数是 BaseModel 类型时，FastAPI 默认会从请求体 JSON 中读取数据。​

Pydantic 主要负责：​

- •定义数据格式。​
- •自动进行类型转换。​
- •对字段进行验证。​
- •提供清晰的数据结构。​

#### 4.1定义 Pydantic 模型 (BaseModel)​

FastAPI 新版本默认使用 Pydantic v2，数据转换使用 `model_dump()`；旧版本中常见的是 `dict()`。​

```
代码块​Pythonfrom fastapi import FastAPI​from pydantic import BaseModel​from typing import Optional​​app = FastAPI()​​​# 定义请求数据模型​class Item(BaseModel):​    name: str​
```

客户端发送请求：​

```
代码块​Python{​    "name": "iPhone",​    "price": 7999,​    "tax": 500​}​
```

FastAPI 会自动完成：​

1. 1.接收 JSON 数据。​
2. 2.根据 `Item` 模型检查字段。​
3. 3.将 JSON 转换成 `Item` 对象。​
4. 4.将对象传入接口函数。​

因此在函数内部：​

```
代码块​Pythonitem.name​item.price​
```

都可以直接访问对应的数据。​

### 5.进阶参数验证​

在实际项目中，仅仅定义数据类型通常是不够的。​

例如：​

- •用户年龄不能小于 0。​
- •商品价格不能超过限制。​
- •用户名长度需要符合要求。​
- •查询关键词长度需要限制。​

FastAPI 提供了 `Query`、`Path`、`Body` 等工具进行参数校验，Pydantic 提供 `Field` 对模型字段进行验证。​

常见应用：​

- •**Path / Query 校验：**用于路径参数和查询参数。​
- •**Field 校验：**用于 Pydantic 模型中的字段验证。​

```
代码块​Python
```

**一些参数的解释**​

- •`gt`: greater than (大于)​
- •`lt`: less than (小于)​
- •`ge`: greater than or equal (大于等于)​
- •`le`: less than or equal（小于等于)​
- •`...` (Ellipsis): 在 Pydantic 中，如果字段没有默认值，本身也是必填字段；使用 `...` 可以显式表示“没有默认值，并且需要进行额外配置”。​

## 第 4 章：响应模型与错误处理​

### 1.响应模型 (Response Model)​

在 FastAPI 中，可以通过路由装饰器中的 `response_model` 参数指定接口返回的数据结构。​

响应模型不仅可以约束接口返回的数据格式，还可以在实际开发中提升接口安全性和可维护性。​

主要作用：​

1. 1.**数据过滤：**只返回响应模型中定义的字段，可以避免意外暴露敏感信息。例如用户密码、内部状态字段等。​
2. 2.**数据校验与转换：**FastAPI 会根据响应模型对返回数据进行校验，并自动转换为符合 JSON 标准的数据格式。​
3. 3.**自动生成接口文档：**Swagger UI 会根据响应模型生成对应的响应 Schema，方便前后端开发人员查看接口返回结构。​

```
代码块​Pythonfrom fastapi import FastAPI​from pydantic import BaseModel​​app = FastAPI()​​​# 接收用户注册信息​class UserIn(BaseModel):​    username: str​    password: str​    email: str​​​# 返回给客户端的用户信息​class UserOut(BaseModel):​    username: str​    email: str​​​@app.post("/user/", response_model=UserOut)​
```

在上面的例子中，请求参数使用 `UserIn` 模型，因为注册用户时需要接收密码。​

但是接口返回数据时使用 `UserOut` 模型，因为密码属于敏感信息，不应该返回给客户端。​

因此，即使函数返回的数据中包含 `password` 字段，FastAPI 也会根据 `response_model` 自动过滤掉该字段。​

实际开发中，通常会为同一个数据对象定义多个模型，例如：​

- •`UserCreate`：用于接收创建用户的数据。​
- •`UserUpdate`：用于接收修改用户的数据。​
- •`UserResponse`：用于返回给客户端的数据。​

通过输入模型和输出模型分离，可以避免接口暴露不必要的数据。​

### 2.HTTP 状态码的选择艺术​

HTTP 状态码是客户端和服务器之间约定的一种通信方式，用于表示一次请求的处理结果。​

在开发 API 时，合理选择状态码可以帮助客户端快速判断请求是否成功，以及失败的原因。​

| ​**状态码**​​ | ​**含义**​​ | ​**适用场景**​​ |
| --- | --- | --- |

​**状态码**​​

**状态码**​

​**含义**​​

**含义**​

​**适用场景**​​

**适用场景**​

​状态码​​

状态码​

​含义​​

含义​

​适用场景​​

适用场景​

​200 OK​​

200 OK​

​请求成功​​

请求成功​

​查询数据、更新数据成功​​

查询数据、更新数据成功​

​201 Created​​

201 Created​

​创建成功​​

创建成功​

​成功创建新的资源，例如注册用户、创建订单​​

成功创建新的资源，例如注册用户、创建订单​

​202 Accepted​​

202 Accepted​

​请求已接受​​

请求已接受​

​请求已经接收，但任务会在后台异步处理，例如文件处理、模型训练任务​​

请求已经接收，但任务会在后台异步处理，例如文件处理、模型训练任务​

​400 Bad Request​​

400 Bad Request​

​请求错误​​

请求错误​

​请求参数符合格式，但业务逻辑不正确，例如参数范围错误、除数为 0​​

请求参数符合格式，但业务逻辑不正确，例如参数范围错误、除数为 0​

​401 Unauthorized​​

401 Unauthorized​

​未认证​​

未认证​

​用户未登录、Token 无效或过期​​

用户未登录、Token 无效或过期​

​403 Forbidden​​

403 Forbidden​

​无权限​​

无权限​

​用户身份已验证，但没有访问该资源的权限​​

用户身份已验证，但没有访问该资源的权限​

​404 Not Found​​

404 Not Found​

​资源不存在​​

资源不存在​

​查询的数据不存在，例如用户 ID 不存在​​

查询的数据不存在，例如用户 ID 不存在​

​422 Unprocessable Entity​​

422 Unprocessable Entity​

​参数校验失败​​

参数校验失败​

​请求数据格式不符合接口要求，例如缺少字段、字段类型错误​​

请求数据格式不符合接口要求，例如缺少字段、字段类型错误​

​500 Internal Server Error​​

500 Internal Server Error​

​服务器内部错误​​

服务器内部错误​

​后端代码出现未处理异常​​

后端代码出现未处理异常​

在 FastAPI 中，如果请求参数无法通过 Pydantic 模型校验，默认会返回 `422 Unprocessable Entity`。​

例如：​

```
代码块​Pythonclass User(BaseModel):​    age: int​
```

客户端传入：​

```
代码块​Python{​    "age": "abc"​}​
```

由于 `age` 要求是整数类型，FastAPI 会自动进行校验并返回 422 错误。​

### 3.异常处理 (Exception Handling)​

在实际项目中，接口运行过程中经常会遇到各种异常情况，例如：​

- •查询的数据不存在。​
- •用户没有登录。​
- •用户没有操作权限。​
- •请求参数不符合业务要求。​

FastAPI 推荐通过抛出异常的方式处理错误，而不是手动返回错误字典。​

这样可以让异常处理逻辑和正常业务逻辑分离，提高代码可维护性。​

#### 3.1使用 HTTPException​

FastAPI 提供了 `HTTPException` 用于主动返回 HTTP 错误响应。​

```
代码块​Pythonfrom fastapi import FastAPI, HTTPException​​app = FastAPI()​​​items = {​    "foo": "The Foo Wrestlers"​}​​​
```

当客户端访问不存在的商品时：​

```
代码块​PythonGET /items/bar​
```

程序会主动抛出：​

```
代码块​Python
```

FastAPI 会自动捕获这个异常，并返回对应的 HTTP 响应：​

```
代码块​Python{​    "detail": "Item not found"​}​
```

相比直接返回错误信息，使用异常机制可以让代码结构更加清晰。​

#### 3.2自定义全局异常处理器​

HTTPException 主要用于主动返回业务相关 HTTP 错误，例如 404、403；而数据库异常、代码异常通常需要另外定义异常处理器。​

为了保持 API 返回格式的统一（例如无论成功失败都返回 `code`, `msg`, `data`），我们需要自定义异常处理。​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

```
代码块​Pythonfrom fastapi import FastAPI, HTTPException, Request​from fastapi.responses import JSONResponse​​​# 1. 初始化 FastAPI 应用​app = FastAPI()​​​# 2. 注册 HTTPException 全局异常处理器​@app.exception_handler(HTTPException)​async def http_exception_handler(​
```

在这个例子中：​

- •当商品 ID 小于 1 时，主动抛出 `400` 异常。​
- •当商品 ID 为 `999` 时，抛出 `404` 异常。​
- •异常会被 `http_exception_handler` 捕获，并转换成统一格式返回。​

其中：​

- •`request` 参数表示当前客户端请求的信息，例如请求路径、请求方法等。​
- •`exc` 参数表示当前发生的异常对象，可以通过 `exc.status_code` 获取状态码，通过 `exc.detail` 获取错误描述。​

在大型项目中，除了处理 `HTTPException` 外，还通常会针对数据库异常、业务异常、自定义异常等情况编写不同的异常处理器，使整个系统的错误管理更加规范。​

# 第三阶段：数据库集成与架构设计​

## 第 5 章：数据库 ORM 集成 (SQLModel)​

前置知识：​[MySQL 从入门到实战](https://q0kyes8lnt5.feishu.cn/wiki/JvLxwNgRQi2W13ksTQRcaY4TnNf)​

### 1.为什么我们需要 ORM？​

在传统的 Web 开发中，我们通常需要通过 SQL 语句直接操作数据库，也就是所谓的 Raw SQL。对于简单项目来说，这种方式非常直接，也具有很高的灵活性，但是随着项目规模不断扩大，数据库操作会越来越多，代码维护也会逐渐变得复杂。​

例如，使用原生 SQL 查询用户信息：​

```
代码块​Python# 传统方式：手写 SQL​import sqlite3​​conn = sqlite3.connect('database.db')​cursor = conn.cursor()​​# 查询用户​cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))​result = cursor.fetchone()​​# 手动构造对象​user = {​    'id': result[0],​    'name': result[1],​    'email': result[2]​}​
```

从这段代码中，我们可以发现一些比较典型的问题：​

1. 1.**需要手动编写 SQL：**查询、新增、修改、删除等操作都需要自己编写对应的 SQL。一个项目中如果有很多数据表，就会产生大量重复的数据库操作代码。​
2. 2.**数据转换比较繁琐：**`fetchone()` 查询出来的结果通常是元组，需要通过 `result[0]`、`result[1]` 这种方式手动取出数据，再转换成 Python 字典或对象。​
3. 3.**维护成本较高：**如果数据库表增加、删除或修改了字段，不仅 SQL 语句可能需要修改，后面的 `result[0]`、`result[1]` 等数据转换逻辑也可能需要同步调整。​
4. 4.**类型关联较弱：**数据库中的字段和 Python 代码中的类型没有建立明确的对应关系，IDE 很难根据数据库表结构提供完整的类型提示。​
5. 5.**容易产生安全问题：**如果开发时直接通过字符串拼接 SQL，而没有使用参数化查询，就可能产生 SQL 注入风险。"select * from users where name = ' " + username +  " ' "​

**ORM (Object-Relational Mapping，对象关系映射)** 是一种技术，它允许开发者使用面向对象编程语言（如 Python）来操作关系型数据库。​

- •**核心思想**：​类 (Class) ↔数据库表 (Table)​对象 (Instance) ↔表中的行 (Row)​

类 (Class) ↔数据库表 (Table)​

对象 (Instance) ↔表中的行 (Row)​

属性 (Attribute) ↔ 表中的列 (Column)​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

例如：​

数据库中有一张 `books` 表：​

| ​id​​ | ​title​​ | ​author​​ | ​price​​ |
| --- | --- | --- | --- |

​id​​

id​

​title​​

title​

​author​​

author​

​price​​

price​

​1​​

1​

​Python 入门​​

Python 入门​

​Tom​​

Tom​

​59.9​​

59.9​

通过 ORM 后，可以映射成 Python 类：​

```
代码块​Pythonclass Book:​    id: int​    title: str​    author: str​    price: float​
```

之后不需要直接编写 SQL，而是通过对象完成数据库操作：​

```
代码块​Python
```

ORM 会自动将对象转换为对应的 SQL：​

```
代码块​SQL
```

在现代 Web 后端开发中，ORM 已经成为常见的数据访问方式。例如 FastAPI、Django、Spring Boot 等框架生态中，都广泛使用 ORM 简化数据库开发。​

### 2.工具选择：SQLModel​

在 Python ORM 生态中，最成熟、使用最广泛的 ORM 框架之一是 <u>SQLAlchemy</u>。​

SQLAlchemy 功能强大，可以支持复杂的数据库操作，但在 FastAPI 项目中，通常还需要配合 Pydantic 定义接口数据模型。​

这会产生一个常见问题：​

> ​数据库模型和接口数据模型需要分别定义，导致大量重复代码。​​

数据库模型和接口数据模型需要分别定义，导致大量重复代码。​

例如：​

```
代码块​Python# 问题示例：重复定义模型​​# 1. 定义 SQLAlchemy 模型（用于数据库）​class UserDB(Base):​
```

可以看到：​

两个模型描述的是同一个用户实体，但需要重复声明字段。这违反了软件开发中的 DRY（Don't Repeat Yourself）原则。​

为了减少这种重复，FastAPI 作者 <u>Sebastián Ramírez</u> 开发了 **SQLModel**。​

**SQLModel** 是一个基于 SQLAlchemy 和 Pydantic 的 ORM 框架，它结合了两者的优势：​

- •**一次定义，多种用途：**一个模型既可以作为数据库表模型，也可以作为数据验证模型使用。​
- •**完善的类型提示：**​一个模型既可以作为数据库表模型，也可以作为数据验证模型使用。​

一个模型既可以作为数据库表模型，也可以作为数据验证模型使用。​

**SQLModel 的优势**：​

SQLModel 是 FastAPI 作者专门开发的 ORM 库，它完美融合了 Pydantic 和 SQLAlchemy 的优点：​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

**核心特性**：​

1. 1.**一次定义，双重身份**：既是 Pydantic 模型又是 SQLAlchemy 模型​
2. 2.**完美类型提示**：IDE 智能补全体验极佳​
3. 3.**异步支持**：SQLModel 可以与 SQLAlchemy 的异步能力结合使用，在 FastAPI 异步项目中可以通过 SQLAlchemy 提供的 AsyncSession 实现异步数据库操作。​
4. 4.**简洁优雅**：减少数据库模型和数据校验模型之间的重复定义，使代码更加简洁。​

### 3.环境搭建与模型定义​

#### 3.1安装依赖​

我们需要安装 `sqlmodel` 以及异步 SQLite 驱动 `aiosqlite`。​

```
代码块​Python# 安装 SQLModel（包含 SQLAlchemy 和 Pydantic）​pip install sqlmodel​​# 安装异步 SQLite 驱动​pip install aiosqlite​​# 安装异步 Pytest-asyncio 插件​pip install pytest-asyncio​​# 如果使用清华源​pip install sqlmodel aiosqlite -i https://pypi.tuna.tsinghua.edu.cn/simple/​​
```

#### 3.2 定义数据模型 (Model)​

在项目中创建一个 `models.py` 文件。​

```
代码块​Pythonfrom typing import Optional​from sqlmodel import SQLModel, Field​​class Book(SQLModel, table=True):​    """​    图书模型​    ​    参数说明：​    - table=True: 标记这是一个数据库表模型​    - Field(): SQLModel 专用的字段定义工具​    """​    ​    # 主键字段​    id: Optional[int] = Field(​        default=None,           # 新建时不需要提供，数据库自动生成​
```

#### 3.3 Field 参数详解​

让我详细讲解 Field 的常用参数：​

| ​**参数**​​ | ​**说明**​​ | ​**示例**​​ |
| --- | --- | --- |

​**参数**​​

**参数**​

​**说明**​​

**说明**​

​**示例**​​

**示例**​

​default​​

default​

​默认值​​

默认值​

​Field(default=None)​​

Field(default=None)​

​primary_key​​

primary_key​

​是否为主键​​

是否为主键​

​Field(primary_key=True)​​

Field(primary_key=True)​

​index​​

index​

​是否创建索引​​

是否创建索引​

​Field(index=True)​​

Field(index=True)​

​nullable​​

nullable​

​是否允许为 NULL​​

是否允许为 NULL​

​Field(nullable=False)​​

Field(nullable=False)​

​unique​​

unique​

​是否唯一​​

是否唯一​

​Field(unique=True)​​

Field(unique=True)​

​gt​​

gt​

​大于（greater than）​​

大于（greater than）​

​Field(gt=0)​​

Field(gt=0)​

​ge​​

ge​

​大于等于​​

大于等于​

​Field(ge=0)​​

Field(ge=0)​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

​​

lt​

小于​

Field(lt=100)​

le​

小于等于​

Field(le=100)​

max_length​

最大长度​

Field(max_length=50)​

description​

字段描述（用于文档）​

Field(description="用户名")​

### 4. 数据库连接与异步 Session​

在现代 FastAPI 开发中，我们推荐使用 **异步数据库会话 (Async Session)** 以避免阻塞主线程。​

#### 4.1为什么使用异步？​

在传统的同步编程中，数据库查询会阻塞线程：​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

而异步编程可以在等待数据库响应时处理其他请求：​

#### 4.2配置数据库连接​

在项目中创建 `database.py` 文件，用于管理数据库连接和 Session。​

SQLModel 底层使用 SQLAlchemy 的数据库连接机制，因此异步数据库配置主要使用 SQLAlchemy 提供的组件：​

- •`create_async_engine`​◦创建异步数据库引擎；​◦负责管理数据库连接池；​◦提供执行 SQL 的能力。​
- ◦创建异步数据库引擎；​
- ◦负责管理数据库连接池；​
- ◦提供执行 SQL 的能力。​
- •`AsyncSession`​◦异步数据库会话对象；​◦用于执行查询、新增、修改、删除等数据库操作。​
- ◦异步数据库会话对象；​
- ◦用于执行查询、新增、修改、删除等数据库操作。​
- •`async_sessionmaker`​◦Session 工厂；​◦用于统一创建数据库会话。​
- ◦Session 工厂；​
- ◦用于统一创建数据库会话。​

代码如下：​

```
代码块​Pythonfrom sqlalchemy.ext.asyncio import (​    create_async_engine,​    AsyncSession,​    async_sessionmaker​)​​from sqlmodel import SQLModel​​​# 数据库连接地址​DATABASE_URL = "sqlite+aiosqlite:///./books.db"​​​# 1. 创建异步数据库引擎​engine = create_async_engine(​
```

##### 数据库 URL 说明​

SQLAlchemy 的数据库连接地址通常遵循以下格式：​

```
代码块​Plain Text数据库类型+驱动://用户名:密码@主机:端口/数据库名称​
```

例如：​

```
代码块​Python# MySQL 数据库​​DATABASE_URL = (​    "mysql+aiomysql://"​    "root:123456"​    "@localhost:3306/"​    "books_db"​)​
```

其中：​

mysql 表示数据库类型。​

Aiomysql 表示异步数据库驱动。​

对于 SQLite：​

```
代码块​Plain TextDATABASE_URL = "sqlite+aiosqlite:///./books.db"​
```

表示：sqlite + aiosqlite异步驱动 + 当前目录下 books.db 文件​

##### init_db() 方法解析​

在初始化数据库时：​

```
代码块​Plain Text
```

这里的 `engine.begin()` 创建的是：​

```
代码块​Plain Text
```

并自动开启一个事务。​

执行流程：获取数据库连接 -> 开启事务 -> 执行数据库操作 -> 成功：自动提交事务 / 失败：自动回滚事务 -> 释放连接​

注意：​

> ​`engine.begin()` 创建的是 Connection，不是 Session。​​

`engine.begin()` 创建的是 Connection，不是 Session。​

在 SQLAlchemy 中：​

| ​对象​​ | ​作用​​ | ​使用场景​​ |
| --- | --- | --- |

​对象​​

对象​

​作用​​

作用​

​使用场景​​

使用场景​

​Engine​​

Engine​

​管理数据库连接池​​

管理数据库连接池​

​项目启动时创建一次​​

项目启动时创建一次​

​Connection​​

Connection​

​负责执行底层 SQL​​

负责执行底层 SQL​

​底层数据库操作​​

底层数据库操作​

​Session​​

Session​

​管理 ORM 对象和业务数据库操作​​

管理 ORM 对象和业务数据库操作​

​业务代码中增删改查​​

业务代码中增删改查​

​Transaction​​

Transaction​

​管理一次数据库事务​​

管理一次数据库事务​

​保证多步写操作的原子性​​

保证多步写操作的原子性​

##### conn.run_sync()​

由于 SQLModel.metadata.create_all 本身是同步方法。​

但是当前代码运行在异步环境：​

```
代码块​Python
```

所以需要：​

```
代码块​Python
```

将同步方法放到异步连接中执行。​

##### SQLModel.metadata.create_all​

作用：​

1. 1.获取所有已经注册的 SQLModel 模型：​

例如：​

```
代码块​Pythonclass Book(SQLModel, table=True):​    ...​
```

1. 2.根据模型定义生成建表 SQL：​

例如：​

```
代码块​Python
```

1. 3.执行 SQL 创建数据库表。​

如果数据库中已经存在对应表：create_all() 不会重复创建。​

##### 两种方式​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

#### 4.3数据库连接流程图​

### 5.CRUD 实战 (增删改查) - Service 文件​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

在 FastAPI 路径操作函数中，我们将演示如何操作数据库。​

#### 5.1Create (新增)​

业务流程：​

代码实现：​

```
代码块​Python
```

**关键点讲解**：​

**注意： session.add 仅加入内存会话，无 IO 操作；commit/refresh 才是数据库交互，才要加 await**​

1. 1.**session.add()**：将对象标记为"待保存"​
2. 2.**await session.commit()**：执行实际的 INSERT 操作​
3. 3.**await session.refresh()**：从数据库重新加载对象，获取自增 ID​

#### 5.2Read (查询)​

SQLAlchemy Async 查询通常使用：from sqlalchemy import select​

常见查询方式：​

| ​**方法**​​ | ​**适用场景**​​ | ​**示例**​​ |
| --- | --- | --- |

​**方法**​​

**方法**​

​**适用场景**​​

**适用场景**​

​**示例**​​

**示例**​

​session.get()​​

session.get()​

​根据主键查询​​

根据主键查询​

​session.get(Book,1)​​

session.get(Book,1)​

​select(Model)​​

select(Model)​

​查询列表​​

查询列表​

​select(Book)​​

select(Book)​

​where()​​

where()​

​条件查询​​

条件查询​

​where(Book.price>50)​​

where(Book.price>50)​

​limit()​​

limit()​

​限制数量​​

限制数量​

​limit(10)​​

limit(10)​

1. 1.**查询所有图书**：​

```
代码块​Pythonasync def get_books() -> list[Book]:​​    async with async_session() as session:​​        statement = select(Book)​​
```

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

1. 2.**根据 ID 查询单个图书**：​

```
代码块​Pythonfrom typing import Optional​​​async def get_book_by_id(​    book_id:int​) -> Optional[Book]:​​​    async with async_session() as session:​​        book = await session.get(​
```

1. 3.**条件查询（按标题搜索）**：​

```
代码块​Pythonasync def search_books_by_title(​    keyword:str​) -> list[Book]:​​    async with async_session() as session:​​        statement = select(Book).where(​            Book.title.contains(keyword)​        )​​        result = await session.execute(statement)​​        return result.scalars().all()​
```

#### 5.3Update (修改)​

更新流程：​

修改数据的逻辑：先查询 -> 修改属性 -> 保存。​

```
代码块​Python
```

#### 5.4Delete (删除)​

```
代码块​Pythonasync def delete_book(​    book_id:int​) -> bool:​​    async with async_session() as session:​​        book = await session.get(​            Book,​            book_id​        )​​        if not book:​            return False​​        await session.delete(book)​​
```

#### 5.5完整测试代码​

让我们编写一个完整的测试，演示所有 CRUD 操作：​

```
代码块​Pythonimport pytest​​from book_service import *​from database import *​from models import Book​​​@pytest.mark.asyncio​async def test_book_crud_operations():​​    await init_db()​​    book = Book(​
```

## 第 6 章：依赖注入系统 (Dependency Injection)​

在实际开发 FastAPI 项目时，随着业务复杂度不断增加，我们会发现很多代码存在重复问题。​

例如，一个接口需要操作数据库：​

```
代码块​Python# ❌ 不推荐写法：​# 每个接口内部自己创建数据库 Session​​async def create_book(book: Book):​​    async with async_session() as session:​​        session.add(book)​​        await session.commit()​​        await session.refresh(book)​​        return book​​​
```

这种写法虽然可以运行，但是随着项目扩大，会带来一些明显的问题：​

1. 1.**代码重复**​

每个业务函数都需要重复创建数据库 Session：​

```
代码块​Pythonasync with async_session() as session:​
```

当项目中存在几十甚至上百个接口时，大量重复代码会导致：​

- •修改成本增加；​
- •容易遗漏资源释放；​
- •项目维护困难。​

1. 2.**难以测试**​

实际开发中，我们经常需要进行单元测试。​

例如：​

测试业务逻辑时：​

```
代码块​Pythonsession = MockSession()​
```

希望使用模拟数据库替代真实数据库。​

但是如果 Session 在函数内部创建：​

```
代码块​Pythonasync with async_session():​
```

那么外部无法方便替换，代码与数据库实现产生强耦合。​

导致：​

- •测试必须连接真实数据库；​
- •测试速度慢；​
- •测试环境搭建复杂。​

1. 3.**职责混乱**​

一个函数同时负责：​

- •处理业务逻辑​
- •创建数据库连接​
- •管理资源释放​

例如：​

```
代码块​Pythonasync def create_book():​​    # 创建资源​    session = create_session()​​    # 业务逻辑​    save_book()​
```

一个函数承担多个职责，导致代码耦合度较高，不符合良好的软件设计原则。​

因此，在实际项目中，我们通常会将这些公共资源抽离出来，通过 **依赖注入（Dependency Injection）**统一管理。​

### 1.什么是依赖注入？​

**依赖注入 (Dependency Injection, DI)** 是软件工程中一种设计模式，也是 FastAPI 的“灵魂”特性。​

- •**核心问题**：假如你的函数 A 需要用到数据库连接 B，通常你在 A 内部创建 B。但这会导致代码耦合度高，难以测试。           ​
- •**DI 的解法**：函数 A 不自己创建 B，而是“声明”它需要 B。框架负责创建 B 并传给 A。​

**通俗比喻**：​

- •**非 DI**：你要吃饭，自己去买菜、做饭、洗碗。​
- •**DI**：你要吃饭，只需在订单上备注（声明依赖），外卖员（FastAPI）会把做好的饭（依赖对象）送到你手上。​

### 2.基本用法：Depends​

Depends 是 FastAPI 提供的依赖声明函数。​

它的作用是告诉 FastAPI：​

“当前函数需要某个依赖，请在执行接口之前自动调用对应依赖函数，并把结果注入进来。”​

```
代码块​Pythonfrom fastapi import Depends, FastAPI​​app = FastAPI()​​
```

访问：GET /items/?q=python&skip=10&limit=20​

FastAPI 会自动执行：​

```
代码块​Pythoncommon_parameters(​    q="python",​    skip=10,​    limit=20​)​
```

然后把返回值：​

```
代码块​Python{​    "q": "python",​    "skip": 10,​    "limit": 20​}​
```

传递给：read_items()​

#### 2.1依赖注入流程：​

#### 2.2依赖的层级嵌套​

FastAPI 的依赖不仅可以被路由使用，依赖本身也可以继续依赖其他依赖。​

```
代码块​Pythonfrom fastapi import Depends, Header, FastAPI​​app = FastAPI()​​​# 第一层依赖：获取 Token​async def get_token(​    token: str = Header(...)​):​    return token​​​# 第二层依赖：依赖 get_token​async def get_current_user(​    token: str = Depends(get_token)​):​    # 实际项目中这里通常会：​
```

### 3.核心场景：数据库 Session 的生命周期管理​

在 FastAPI 项目中，依赖注入最常见的使用场景之一，就是管理数据库 Session。​

数据库 Session 属于一种典型的**短生命周期资源：**​

- •请求开始时，需要创建 Session；​
- •请求处理过程中，需要使用 Session 操作数据库；​
- •请求结束后，需要关闭 Session，释放数据库连接。​

如果每个接口都手动创建和关闭 Session：​

```
代码块​Pythonasync def create_book():​    async with async_session() as session:​        ...​
```

项目中会出现大量重复代码，同时也容易出现资源释放不及时的问题。​

因此，我们通常会将 Session 的创建和销毁交给依赖注入统一管理。​

#### 3.1为什么需要管理 Session 生命周期？​

一个 HTTP 请求对应一个数据库操作过程。如果没有正确管理生命周期，可能产生以下问题：​

1. 1.**每个请求需要独立 Session**​

不同请求之间不应该共享同一个数据库 Session。​

例如：​

```
代码块​Plain Text请求 A -> Session A​请求 B -> Session B​
```

这样可以避免多个请求之间的数据状态相互影响。​

1. 2.**请求结束后释放连接**​

数据库连接属于有限资源。​

如果创建 Session 后没有关闭：​

```
代码块​Plain Text请求1 → 创建连接​请求2 → 创建连接​请求3 → 创建连接​...​
```

随着请求增加，数据库连接可能耗尽，因此请求结束后必须及时释放资源。​

1. 3.**异常情况下也需要清理资源**​

接口执行过程中可能发生异常：​

```
代码块​Pythonawait session.commit()​
```

可能因为数据库错误失败。即使出现异常，也应该保证 Session 能够正常关闭。​

#### 3.2使用 yield 实现依赖​

FastAPI 支持使用 `yield` 创建带生命周期管理的依赖。​

[unknown: 嵌入内容](https://lf-fb.feishupkg.com/obj/larkdeveloper/app/cli_a39553a60f3a900b/current/web_offline/1791433210764_9x8bl9uv7n/index.html?uuid=0fe5d832cc4b9658d19c979308fe0ecd16cc3941&render_times=1&is_online=true)

例如：​

```
代码块​Pythonasync def get_session():​​    session = create_session()​​    try:​​        yield session​​    finally:​​        await session.close()​
```

因此，`yield` 非常适合处理：​

- •数据库连接​
- •文件操作​
- •网络连接​
- •锁资源​

等需要“使用前创建，使用后释放”的场景。​

##### yield 的执行特点​

普通函数：​

```
代码块​Pythondef func():​
```

执行到 `return` 后，函数直接结束。​

生成器：​

```
代码块​Python
```

执行到 `yield` 后：​

- •暂停函数执行；​
- •保存当前状态；​
- •返回值给调用方；​
- •后续可以继续恢复执行。​

例如：​

```
代码块​Pythondef get_resource():​​    print("创建资源")​​    yield "resource"​​    print("释放资源")​
```

第一次执行：next(generator)​

执行：​

```
代码块​Python创建资源​​返回 resource​
```

再次执行 next(generator)，继续释放资源​

##### FastAPI 中的 yield 依赖​

在 FastAPI 中，我们不需要自己调用 next() 或者 __anext__()​

因为 FastAPI 的依赖系统会自动管理整个生命周期。​

例如：​

```
代码块​Pythonasync def get_session():​​    session = create_session()​​    yield session​​    await session.close()​
```

#### 3.3 生成器类型说明​

在 Python 中，根据是否支持异步操作，生成器主要分为两种：​

| ​类型​​ | ​定义方式​​ | ​使用场景​​ |
| --- | --- | --- |

​类型​​

类型​

​定义方式​​

定义方式​

​使用场景​​

使用场景​

​​

​​

​​

​​

​​

​​

Generator​

def + yield​

同步资源管理​

AsyncGenerator​

async def + yield​

异步资源管理​

FastAPI 异步接口中通常使用 AsyncGenerator​

##### 同步生成器 Generator​

类型：​

```
代码块​PythonGenerator[YieldType, SendType, ReturnType]​
```

三个泛型参数：​

| ​参数​​ | ​含义​​ |
| --- | --- |

​参数​​

参数​

​含义​​

含义​

​YieldType​​

YieldType​

​yield 返回的数据类型​​

yield 返回的数据类型​

​SendType​​

SendType​

​外部发送给生成器的数据类型​​

外部发送给生成器的数据类型​

​ReturnType​​

ReturnType​

​生成器最终返回值类型​​

生成器最终返回值类型​

例如：​

```
代码块​Pythondef get_names():​    yield "张三"​    yield "李四"​    ​def demo():​    yield "hello"​    return "结束"​        ​Generator[str, None, None]​
```

表示：​

- •yield 一个字符串；​
- •不接收外部数据；​
- •没有最终返回值。​

##### 异步生成器 AsyncGenerator​

类型：​

```
代码块​Python
```

例如：​

```
代码块​Python
```

表示 yield 一个 AsyncSession，没有最终返回值。​

**一、生成器的暂停与恢复机制**​

无论同步还是异步生成器，本质都是：​

> ​遇到 yield 暂停，把数据交给调用方；再次恢复执行时，从 yield 后继续运行。​​

遇到 yield 暂停，把数据交给调用方；再次恢复执行时，从 yield 后继续运行。​

例如：​

```
代码块​Pythondef generator():​​    print("开始")​​    yield "数据"​​    print("结束")​
```

执行 gen = generator()：此时没有输出，因为函数还没有真正执行。第一次唤醒 next(gen) ，输出开始，返回数据。再次唤醒 next(gen)，输出结束​

**二、同步生成器：用**`**next()**`**唤醒**​

同步生成器通过 next() 恢复执行​

示例：​

```
代码块​Pythonfrom typing import Generator​
```

**三、异步生成器：使用 await anext()**​

异步生成器通过 await anext(generator) 或者底层方法：await generator.__anext__() 恢复执行，不能使用 next() 否则会产生错误​

示例：​

```
代码块​Python
```

**四、同步**`**next()**`** vs 异步**`**__anext__()**`** 极简对比**​

| ​对比项​​ | ​同步生成器 next()​​ | ​异步生成器 anext()​​ |
| --- | --- | --- |

​对比项​​

对比项​

​同步生成器 next()​​

同步生成器 next()​

​异步生成器 anext()​​

异步生成器 anext()​

​定义方式​​

定义方式​

​def + yield​​

def + yield​

​async def + yield​​

async def + yield​

​调用方式​​

调用方式​

​next(generator)​​

next(generator)​

​await generator.__anext__()​​

await generator.__anext__()​

​使用环境​​

使用环境​

​同步代码​​

同步代码​

​异步代码​​

异步代码​

​结束异常​​

结束异常​

​StopIteration​​

StopIteration​

​StopAsyncIteration​​

StopAsyncIteration​

​常见场景​​

常见场景​

​普通资源管理​​

普通资源管理​

​FastAPI 异步接口、数据库 Session​​

FastAPI 异步接口、数据库 Session​

**五、为什么 FastAPI 不需要手动调用 next()？**​

核心原因：​

FastAPI 会自动管理依赖生成器生命周期。​

对于 yield 类型依赖：​

- •请求开始时执行 yield 前代码，创建资源；​
- •将 yield 的对象注入接口；​
- •请求结束后继续执行 yield 后代码，完成资源释放。​

底层实现涉及生成器恢复机制，但开发者不需要手动调用 next() 或 __anext__()。​

**优势 1：减少重复代码**​

接口函数只关注业务逻辑：​

```
代码块​Pythonasync def create_book(​    session: AsyncSession = Depends(get_session)​):​    ...​
```

不需要每个接口重复：​

```
代码块​Pythonasync with async_session() as session:​
```

**优势 2：保证资源安全释放**​

即使接口发生异常：​

```
代码块​Pythonraise HTTPException(​    status_code=400,​    detail="参数错误"​)​
```

FastAPI 仍然会执行 `yield` 后面的清理逻辑。​

**优势 3：统一管理资源生命周期**​

数据库连接、文件对象、第三方 API 客户端等，都可以使用相同方式管理​

```
代码块​Python创建资源 -> yield 提供资源 -> 释放资源​
```

#### 3.4** 使用 FastAPI 依赖管理数据库 Session**​

在上一章节中，我们已经实现了 Service 层，并且在 Service 方法中完成数据库操作。​

例如：​

```
代码块​Pythonasync def create_book(book_data: Book) -> Book:​​    async with async_session() as session:​​        session.add(book_data)​​        await session.commit()​​        await session.refresh(book_data)​​        return book_data​
```

这种方式虽然可以正常运行，但是存在一个问题：​

每一个 Service 方法都需要自己创建 Session，并且负责关闭 Session。如果项目越来越大，会出现大量重复代码。实际企业项目中，一般不会让 Service 自己管理 Session 生命周期，而是交给 FastAPI 的依赖注入系统统一管理。​

这样可以让：​

- •FastAPI 负责资源管理；​
- •Service 只负责业务逻辑；​
- •数据库操作代码更加清晰。​

例如：​

项目结构：​

```
代码块​Plain Text
```

其中：​

- •`main.py`​◦定义 FastAPI 路由；​◦接收请求；​◦使用 Depends 获取 Session；​◦调用 Service。​
- ◦定义 FastAPI 路由；​
- ◦接收请求；​
- ◦使用 Depends 获取 Session；​
- ◦调用 Service。​
- •`service/`​◦编写业务逻辑；​◦不负责创建 Session；​◦接收 FastAPI 注入进来的 Session。​
- ◦编写业务逻辑；​
- ◦不负责创建 Session；​
- ◦接收 FastAPI 注入进来的 Session。​
- •`orm/database.py`​◦创建数据库连接；​◦创建 Session 工厂；​◦提供 `get_session()` 依赖。​
- ◦创建数据库连接；​
- ◦创建 Session 工厂；​
- ◦提供 `get_session()` 依赖。​
- •`orm/models.py`​◦定义 SQLModel 数据模型。​
- ◦定义 SQLModel 数据模型。​

**database.py**​

```
代码块​Pythonfrom typing import AsyncGenerator​​from sqlalchemy.ext.asyncio import (​    AsyncSession,​    create_async_engine,​    async_sessionmaker​)​​from sqlmodel import SQLModel​​​# 数据库连接地址​DATABASE_URL = "sqlite+aiosqlite:///./books.db"​​​
```

这里 async with async_session() as session，负责创建 Session。​

而 yield session，负责把 Session 交给接口函数。​

当请求结束后，async with 会自动关闭 Session。​

#### 3.5在 Service 层中接收 Session​

service/book_service.py​

```
代码块​Pythonfrom typing import Optional​​from sqlmodel import select​​from sqlalchemy.ext.asyncio import AsyncSession​​from orm.model import Book​​async def create_book(​    session: AsyncSession,​    book_data: Book​) -> Book:​​    """​
```

#### 3.6在接口中使用 Session 依赖​

在`main.py`写下面代码​

```
代码块​Pythonfrom contextlib import asynccontextmanager​​from fastapi import FastAPI, Depends​​from sqlalchemy.ext.asyncio import AsyncSession​​from orm.database import (​    get_session,​    init_db​)​​from orm.model import Book​​
```

### 4. FastAPI 模块化路由神器：APIRouter​

在之前的学习中，我们已经掌握了 FastAPI 最基础的路由写法 `@app.get("/")`。但随着项目功能越来越复杂，接口越来越多，如果所有代码都堆在 `main.py` 里，会变得非常臃肿、难以维护。​

#### 4.1**为什么需要 APIRouter**​

想象一下，你是图书馆管理员：​

- •**混乱的图书馆（只用 @app.xxx）**：所有的书（用户接口、书籍接口、订单接口）都堆在一个大书架（`main.py`）上。读者要找一本关于 “Python” 的书，你需要翻遍整个书架，效率极低。​
- •**整洁的图书馆（使用 APIRouter）**：你把书按主题分类，放在不同的书架上：​◦**文学区书架**：放小说、诗歌相关的书（对应 `wenxue_router`）。​◦**科技区书架**：放编程、科普相关的书（对应 `keji_router`）。​◦**管理员办公室（main.py）**：负责管理这些书架，告诉读者每个书架在哪里。​
- ◦**文学区书架**：放小说、诗歌相关的书（对应 `wenxue_router`）。​
- ◦**科技区书架**：放编程、科普相关的书（对应 `keji_router`）。​
- ◦**管理员办公室（main.py）**：负责管理这些书架，告诉读者每个书架在哪里。​

`APIRouter` 的作用，就是帮我们创建这些独立的 “主题书架”，让代码按功能模块（如用户、书籍、订单）拆分，结构清晰，维护方便。​

#### 4.2**APIRouter 核心三步骤**​

使用 APIRouter 主要分为三个步骤：​

1. 1.创建路由对象；​
2. 2.在路由对象中定义接口；​
3. 3.注册到 FastAPI 主应用。​

**步骤 1：创建子路由对象**​

通过利用依赖注入，我们可以实现**控制层 (Controller/Router)** 与 **服务层 (Service/Logic)** 的分离。​

- •**Router 层**：负责接收 HTTP 请求，参数校验，调用 Service，返回响应。​
- •**Service 层**：负责具体的业务逻辑，数据库操作。​

```
代码块​Pythonproject/​│​├── main.py                  # FastAPI入口文件​│​
```

首先，我们需要创建一个 `APIRouter` 实例，它代表一个独立的路由模块（一个 “主题书架”）。这里我们新建一个`routers`目录，创建`book_router` 这个书籍路由​

```
代码块​Python# 从 fastapi 中导入 APIRouter​from fastapi import APIRouter​​# 创建一个名为 book_router 的子路由对象​
```

**步骤 2：在子路由上定义接口**​

接下来，我们就可以像使用 `app` 一样，在这个子路由对象上定义各种接口了。​

 Router 的职责主要是：​

- •接收请求参数；​
- •获取 Session；​
- •调用 Service；​
- •返回结果。​

在 `book_router.py` 中：​

```
代码块​Pythonfrom fastapi import APIRouter, Depends​​from sqlalchemy.ext.asyncio import AsyncSession​​from orm.database import get_session​
```

**步骤 3：将子路由注册到主应用**`**main.py**`​

这是最关键的一步！创建好的子路由（书架）必须 “告诉” 主应用（图书馆管理员），否则它不会生效。我们通过 `app.include_router()` 方法完成注册。​

```
代码块​Pythonfrom contextlib import asynccontextmanager​​from fastapi import FastAPI​​​from orm.database import (​    init_db​)​​from routers.book_router import book_router​
```

#### 4.3APIRouter 的高级用法​

除了简单拆分路由外，APIRouter 还提供了一些常用配置，可以进一步优化项目结构。​

常见参数：​

- •prefix​
- •tags​
- •dependencies​

1. 1.**路径前缀（prefix）**​

如果一个模块下的所有接口都有共同的路径前缀（比如都以 `/books` 开头），我们可以在创建 `APIRouter` 时统一指定 `prefix` 参数，避免重复书写。​

**修改 **`**routers/book_router.py**`**：**​

```
代码块​Pythonfrom fastapi import APIRouter, Depends​​from sqlalchemy.ext.asyncio import AsyncSession​​from orm.database import get_session​
```

这样，我们的代码就更简洁了！​

1. 2.**接口文档标签（tags）**​

在接口文档（`/docs`）中，我们可以用 `tags` 参数将不同模块的接口分组显示，让文档结构更清晰。​

**修改 **`**routers/book_router.py**`**：**​

```
代码块​Pythonbook_router = APIRouter(prefix="/books", tags=["书籍管理"])​
```

启动服务器后，访问 `/docs`，你会看到所有书籍相关的接口都被归类到了 “书籍管理” 标签下。​

![飞书文档 - 图片](blob:https://q0kyes8lnt5.feishu.cn/b95e99e5-6372-45c5-b771-26126e315f06)

1. 3.**公共依赖（dependencies）**​

如果一个模块下的所有接口都需要依赖同一个对象（比如都需要用户登录验证），我们可以在 `APIRouter` 上统一添加 `dependencies`，避免在每个接口函数中重复写 `Depends(...)`。​

```
代码块​Pythonfrom fastapi import APIRouter, Depends, HTTPException​​from sqlalchemy.ext.asyncio import AsyncSession​​from orm.database import get_session​
```

![飞书文档 - 图片](images/img_007.png)
