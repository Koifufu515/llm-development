from langchain_openai import ChatOpenAI

from app.config import Settings


def get_deepseek_llm(settings: Settings) -> ChatOpenAI:
    if not settings.model_configured:
        raise ValueError("请先在本机 .env 配置 DEEPSEEK_API_KEY")
    if settings.model_provider == "qwen":
        return ChatOpenAI(model=settings.qwen_model,base_url=settings.qwen_base_url,
            api_key=settings.dashscope_api_key.get_secret_value().strip(),temperature=0,timeout=60,
            max_retries=1,max_tokens=4000,extra_body={"enable_thinking":False})
    return ChatOpenAI(
        model=settings.deepseek_model,
        base_url=settings.deepseek_base_url,
        api_key=settings.deepseek_api_key.get_secret_value().strip(),
        temperature=0,
        timeout=45,
        max_retries=1,
        max_tokens=2000,
        # 当前 DeepSeek 默认可能启用思考；需求收集先采用非思考工具调用。
        extra_body={"thinking": {"type": "disabled"}},
    )
