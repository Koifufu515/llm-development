import asyncio
import os
import sys
import shutil

from langchain_mcp_adapters.client import MultiServerMCPClient

from app.config import PROJECT_ROOT


async def load_weather_tools():
    # 只传网络代理和模块路径，不把模型凭证传入天气子进程。
    env = {key: value for key, value in os.environ.items() if key.lower() in {"http_proxy", "https_proxy", "all_proxy", "no_proxy"}}
    env["PYTHONPATH"] = str(PROJECT_ROOT)
    client = MultiServerMCPClient({"weather": {
        "transport": "stdio", "command": sys.executable,
        "args": ["-m", "app.mcp_core.servers.weather_server"], "env": env,
    }})
    return await asyncio.wait_for(client.get_tools(), timeout=20)


class ProjectMCPManager:
    """每个服务独立发现与降级，工具调用由适配器创建短会话。"""
    def __init__(self):
        self.tools = {}
        self.status = {}

    async def load_service(self, name):
        try:
            if name == 'weather':
                tools = await load_weather_tools()
            else:
                command = shutil.which('node')
                if not command:
                    raise RuntimeError('Node runtime not found')
                client = MultiServerMCPClient({'rail': {
                    'transport':'stdio', 'command':command,
                    'args':[str(PROJECT_ROOT/'infra/rail-mcp/node_modules/12306-mcp/build/index.js')],
                }})
                tools = await asyncio.wait_for(client.get_tools(), timeout=20)
            self.tools[name] = tools
            self.status[name] = 'ready'
        except Exception:
            self.tools[name] = []
            self.status[name] = 'unavailable'
        return self.tools[name]

    async def initialize(self):
        await asyncio.gather(self.load_service('weather'), self.load_service('rail'))
