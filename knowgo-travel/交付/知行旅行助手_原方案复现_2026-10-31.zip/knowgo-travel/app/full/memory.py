"""原文0668的结构化画像、完整出游记录、景点去重和渐进住宿预算。"""
import asyncio,logging
from datetime import datetime,timezone
from typing import List
from langgraph.store.postgres.aio import AsyncPostgresStore
from app.full.memory_models import UserProfile,TravelHistory,TravelRecord,UserMemory
app_logger=logging.getLogger(__name__)

class UserMemoryService:
    """
    用户长期记忆服务
    提供用户画像和出行历史的 CRUD 操作
    """

    def __init__(self, store: AsyncPostgresStore):
        self.store = store

    def _get_current_time(self) -> str:
        """获取当前时间字符串"""
        return datetime.now(timezone.utc).isoformat()

    # ========== 用户画像操作 ==========

    async def get_user_profile(self, user_id: str) -> UserProfile:
        """获取用户画像"""
        try:
            # namespace 是层次化的 tuple，第二段用 user_id 做隔离
            result = await self.store.aget(
                namespace=("user_profiles", user_id),
                key="profile"
            )

            if result and result.value:
                return UserProfile(**result.value)

            # 从来没存过 → 返回空档案
            return UserProfile()

        except Exception as e:
            app_logger.error(f"❌ 获取用户画像失败: {e}")
            return UserProfile()

    async def save_user_profile(self, user_id: str, profile: UserProfile):
        """保存用户画像"""
        profile.updated_at = self._get_current_time()

        await self.store.aput(
            namespace=("user_profiles", user_id),
            key="profile",
            value=profile.model_dump()  # Pydantic → dict
        )

        app_logger.info(f"保存用户画像: {user_id}")

    async def update_travel_styles(self, user_id: str, styles: List[str]):
        """更新旅行风格偏好（合并去重）"""
        profile = await self.get_user_profile(user_id)
        # 用 set 合并，避免重复
        current_styles = set(profile.travel_styles)
        current_styles.update(styles)
        profile.travel_styles = list(current_styles)

        await self.save_user_profile(user_id, profile)

    async def update_dietary_restrictions(self, user_id: str, restrictions: List[str]):
        """更新饮食禁忌（合并去重）"""
        profile = await self.get_user_profile(user_id)
        current = set(profile.dietary_restrictions)
        current.update(restrictions)
        profile.dietary_restrictions = list(current)

        await self.save_user_profile(user_id, profile)

    async def update_food_preferences(self, user_id: str, preferences: List[str]):
        """更新饮食偏好（合并去重）"""
        profile = await self.get_user_profile(user_id)
        current = set(profile.food_preferences)
        current.update(preferences)
        profile.food_preferences = list(current)

        await self.save_user_profile(user_id, profile)

    # ========== 出行历史操作 ==========

    async def get_travel_history(self, user_id: str) -> TravelHistory:
        """获取出行历史"""
        try:
            result = await self.store.aget(
                namespace=("travel_history", user_id),
                key="history"
            )

            if result and result.value:
                return TravelHistory(**result.value)

            return TravelHistory()

        except Exception as e:
            app_logger.error(f"❌ 获取出行历史失败: {e}")
            return TravelHistory()

    async def save_travel_history(self, user_id: str, history: TravelHistory):
        """保存出行历史"""
        history.updated_at = self._get_current_time()

        await self.store.aput(
            namespace=("travel_history", user_id),
            key="history",
            value=history.model_dump()
        )

        app_logger.info(f"保存出行历史: {user_id}")

    async def add_completed_trip(
            self,
            user_id: str,
            destination: str,              # 目的地
            start_date: str,
            end_date: str,
            visited_attractions: List[str] # 游玩过的景点列表
    ):
        """添加已完成的旅行记录"""
        history = await self.get_travel_history(user_id)

        trip = TravelRecord(
            destination=destination,
            start_date=start_date,
            end_date=end_date,
            visited_attractions=visited_attractions
        )
        history.completed_trips.append(trip)

        # 汇总去过的景点（去重）
        current_attractions = set(history.visited_attractions)
        current_attractions.update(visited_attractions)
        history.visited_attractions = list(current_attractions)

        await self.save_travel_history(user_id, history)

        app_logger.info(f"添加旅行记录: {user_id} -> {destination}")

    async def update_accommodation_preference(
            self,
            user_id: str,
            preferred_types: List[str] = None,  # 偏好类型
            avg_budget: float = None            # 每晚预算
    ):
        """更新住宿偏好"""
        history = await self.get_travel_history(user_id)

        if preferred_types:
            current_types = set(history.accommodation_preference.preferred_types)
            current_types.update(preferred_types)
            history.accommodation_preference.preferred_types = list(current_types)

        if avg_budget:
            old_budget = history.accommodation_preference.avg_budget_per_night
            if old_budget:
                # 有旧值就取平均，做"渐进式收敛"
                history.accommodation_preference.avg_budget_per_night = (old_budget + avg_budget) / 2
            else:
                history.accommodation_preference.avg_budget_per_night = avg_budget

        await self.save_travel_history(user_id, history)

        app_logger.info(f"更新住宿偏好: {user_id}")

    # ========== 完整记忆操作 ==========

    async def get_user_memory(self, user_id: str) -> UserMemory:
        """获取用户完整的长期记忆（画像 + 历史，两次查询并行）"""
        # 用 asyncio.gather 让两次数据库查询并行发起，快一倍
        profile, history = await asyncio.gather(
            self.get_user_profile(user_id),
            self.get_travel_history(user_id)
        )

        return UserMemory(
            user_id=user_id,
            profile=profile,
            history=history
        )

    async def format_memory_for_prompt(self, user_id: str) -> str:
        """把用户记忆格式化成 Prompt 可以直接拼进去的文本"""
        memory = await self.get_user_memory(user_id)

        parts = ["**用户历史偏好**："]

        # 用户画像
        if memory.profile.travel_styles:
            parts.append(f"- 旅行风格：{', '.join(memory.profile.travel_styles)}")

        if memory.profile.dietary_restrictions:
            parts.append(f"- 饮食禁忌：{', '.join(memory.profile.dietary_restrictions)}")

        if memory.profile.food_preferences:
            parts.append(f"- 饮食偏好：{', '.join(memory.profile.food_preferences)}")

        # 出行历史
        if memory.history.completed_trips:
            destinations = list(set(t.destination for t in memory.history.completed_trips))
            parts.append(f"- 去过的目的地：{', '.join(destinations[-5:])}")

        visited_attractions = memory.history.visited_attractions
        if visited_attractions:
            parts.append(f"- 去过的景点：{', '.join(visited_attractions[-10:])}（最近10个）")

        # 住宿偏好
        acc_pref = memory.history.accommodation_preference
        if acc_pref.preferred_types:
            parts.append(f"- 住宿偏好：{', '.join(acc_pref.preferred_types)}")

        if acc_pref.avg_budget_per_night:
            parts.append(f"- 住宿预算：约 {acc_pref.avg_budget_per_night:.0f} 元/晚")

        if len(parts) == 1:
            return ""  # 没有历史数据，返回空字符串

        return "\n".join(parts)

